import sys, time, msvcrt


def readInput(timeout = 1):

    """Takes keyboard input from user. Times out after specified seconds"""
       
   
 
    start_time = time.time()

    #Returns empty string if timed out
 
    input = ''

   
    while True:

        if msvcrt.kbhit():

            timeout = 60

            
            chr = msvcrt.getche()

            if ord(chr) == 13: # enter_key

                break

            elif ord(chr) >= 32: #space_char

                input += chr

        if len(input) == 0 and (time.time() - start_time) > timeout:

            break


    
    return input
    
