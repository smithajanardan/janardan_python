#  File: Initials.py

#  Description: My initials, in block text, using letters.

#  Student Name: Smitha Janardan

#  Student UT EID: ssj398

#  Course Name: CS 303E

#  Unique Number: 52220

#  Date Created: 08/28/10

#  Date Last Modified: 08/28/10

############################################################################

print " SSSSSS       JJJJJJJJJ"
print "SSSSSSS       JJJJJJJJJ"
print "SSS              JJJ"
print "SSSSSSS          JJJ"
print "  SSSSSS         JJJ"
print "     SSS         JJJ"
print "SSSSSSSS ..  JJJJJJJ   .."
print "SSSSSSS  ..  JJJJJJ    .."