import random

def parseString (st):
  st = st.replace("\n"," ")
  str = ""
  for ch in st:
    if ch == "-":
      str += ""
    if ch.isalpha() or ch.isspace():
      str += ch
    else:
      str += ""
  return str

def q1(str):
  book = {}
  str = parseString(str).split()
  for elt in str:
    book[elt] = str.count(elt)
  print book 

def q2(a,b):
  c = set(a)
  d = set(b)
  e = c & d
  return list(e)

def q3():
  a = []
  num = 3
  while num > 0:
    b = []
    n = 5
    while n > 0:
      b.append(random.random()*100)
      n = n-1
    num = num -1
  return a

def q4(a, b):
  for elt in a:
    if elt not in b:
      return False
  return True

def q5(a, b):
  d = []
  for i in range(len(a)):
    c = []
    for j in range(len(a[i])):
      e = a[i][j] + b[i][j]
      c.append(e)
    d.append(c)
  print d

def q6(a):
  for elt in a:
    elt.reverse()
  return a

def q7(b):
  c = []
  for i in range(len(b)):
    i = len(b) -1
    c.append(b[i])
  return c

def q8(a, b):
  c = []
  for i in range(len(a)):
    c.append(a[i]*b[i])
  sum = 0
  for elt in c:
    sum += elt
  return sum

def q9(a):
  for i in range(len(a)-1):
    if a[i] > a[i+1]:
      return False
  return True

def q10(a):
  n = len(a)
  for elt in a:
    s = 0
    for item in elt:
      s += int(item)
    print s
  for i in range (n):
    s = 0
    for j in range (n):
      s += int(a[j][i])
    print s
  s = 0
  for i in range (n):
    s += int(a[i][i])
  print s
  s = 0
  for i in range (n):
    s += int(a[i][n-1-i])
  print s
  return True

def q11(b):
  a = []
  if b[0] < b[1] and b[0] < b[2]:
    a.append(0)
  return
  
def q12(b):
  random.shuffle (b)
  return b

def q14(e, f):
  e = parseString(e.lower())
  f = parseString(f.lower())
  for elt in e:
    if f.find(elt) < 0:
      return False
    f.replace(elt, "")
  return True

def q16(n):
  if n == 0:
    return 0
  else:
    return ((2 * q16(n-1)) + n)

def q19(a, lo):
  hi = len (a)
  if (lo == hi):
    print a
  else:
    for i in range (lo, hi):
      a[lo], a[i] = a[i], a[lo]
      q19(a, lo +1)
      a[lo], a[i] = a[i], a[lo]

def q20(a, lo):
  hi = len (a)
  if (lo == hi):
    if (a.index("A") + 1) == a.index("B") or (a.index("A") - 1) == a.index("B"):
      if (a.index("C") + 1) != a.index("D") and (a.index("C") - 1) != a.index("D"):
        print a
  else:
    for i in range (lo, hi):
      a[lo], a[i] = a[i], a[lo]
      q20(a, lo +1)
      a[lo], a[i] = a[i], a[lo]

def q21(a, b, lo, size):
  hi = len(a)
  if lo == hi:
    if len(b) == size:
      if ("A" in b):
        if ("B" in b):
          if "C" in b and "D" in b:
            pass
          else:
            print b
      elif "C" in b and "D" in b:
        pass
      else:
        print b
    return
  else:
    c = b[:]
    b.append(a[lo])
    q21 (a, c, lo + 1, size)
    q21 (a, b, lo + 1, size)

def q22(a, b, lo):
  hi = len(a)
  if lo == hi:
    if sum(b) == 50:
      print b
    return
  else:
    c = b[:]
    b.append(a[lo])
    q22 (a, c, lo + 1)
    q22 (a, b, lo + 1)

def main():
  str = " fhiua; hfaih niah njuiael fyeuila fhli"
  q1(str)
  c = ["nhd", "dhna"]
  d = ["nhd", "dhna"]
  print q2(c,d)
  a = [[2, 4, 5], [3, 5], [3, 6, 6, 6]]
  b = [[4, 6, 8], [5, 7], [3, 6, 9, 8]]
  q5 (a, b)
  print q4(c,d)
  print q6(a)
  print q7(b)
  a = [1, 5, 3]
  b = [4, 5, 6]
  print q8(a,b)
  print q9(a)
  a = [[2, 4, 5], [3, 5, 9], [3, 6, 6]]
  q10(a)
  print q12(b)
  e = "g h h d s"
  f = "h h   d   f-  g"
  print q14(e,f)
  print q16(8)
  a = ['A', 'B', 'C', 'D', 'E', 'F']
  b = []
  q21(a, b, 0, 3)
  a = [15, 9, 30, 21, 19, 3, 12, 6, 25, 27]
  b = []
  q22(a, b, 0)
main()